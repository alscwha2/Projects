Aaron Schwartz-Messing
Mordechai Schmutter

Contains:
	fat32_reader.java
	REAME.txt

Compilation: javac fat32_reader.java
To Run: java fat32_reader <fat32.img file>